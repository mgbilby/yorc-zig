Two gzip members: the tar is split inside the record below.
